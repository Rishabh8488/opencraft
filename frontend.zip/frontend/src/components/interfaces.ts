export interface DragItem {
    type: string
    id: string
    top: number|null
    left: number|null
    emoji: string
    title: string
}
