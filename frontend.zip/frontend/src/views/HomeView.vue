<script setup lang="ts">
import Example from "@/components/Example.vue";
import ItemCard from "@/components/ItemCard.vue";
import Resource from "@/components/Resource.vue";
import AvaliableResources from "@/components/AvailableResources.vue";
import Container from "@/components/Container.vue";
</script>

<template>
  <Example></Example>
</template>
